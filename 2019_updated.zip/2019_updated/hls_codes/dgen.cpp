#include <hls_stream.h>
#include <ap_int.h>

using namespace hls;

// AXIS data struct
struct data_axi_type {
    ap_uint<128> data;
    ap_uint<7>   keep;
    ap_uint<1>   last;
};

typedef stream<data_axi_type> dataStream_type;

// Config stream
typedef stream<ap_uint<128> > configStream_type;

void sbi_config_input(configStream_type &configStream,
                      dataStream_type &dataStream) {

    #pragma HLS INTERFACE axis port=configStream
    #pragma HLS INTERFACE axis port=dataStream
    #pragma HLS INTERFACE ap_ctrl_none port=return

    const ap_uint<128> config_val =
        ap_uint<128>("00408841A046A334000F008902402308", 16);

    const ap_uint<128> data_vals[4] = {
        ap_uint<128>("4AC0AB35BE3A20FF7A7D7FCAD005A332", 16),
        ap_uint<128>("1BBF085C2BC611AE8820839D27ECB2E3", 16),
        ap_uint<128>("A5EE3894885B5289307400E398546B83", 16),
        ap_uint<128>("039E89EED41DC9E5F9AC17512AF70D6B", 16)
    };

    // Send config
    configStream.write(config_val);

    // Send data
    for (int i = 0; i < 4; i++) {

        #pragma HLS PIPELINE II=1

        data_axi_type data_word;

        data_word.data = data_vals[i];

        if (i == 3) {
            data_word.last = 1;
            data_word.keep = 120;
        } else {
            data_word.last = 0;
            data_word.keep = 127;
        }

        dataStream.write(data_word);
    }
}
