`timescale 1ns / 1ps





module design_1_wrapper_tb();

reg [127:0]tdata_in;
reg tvalid_in;
wire tready_in;
reg [6:0]tkeep_in;
reg [0:0]tlast_in;


reg [127:0]tdata_in_config;                    //Interleaver
reg tvalid_in_config;
wire tready_in_config;


wire tvalid_out;
reg tready_out;
wire [95:0]tdata_out;
wire [0:0]tlast_out;




wire clk;
wire rst;



initial begin
#5000 $finish;
end

integer i,j,k,l;
reg [95:0] err_tdata_out;
integer err_count_tdata_out;





reg [127:0] in_data  [0:240000];
reg [0:0] in_last  [0:240000];
reg [6:0] in_keep  [0:240000];
reg [95:0] out_data [0:270000];
reg [127:0] config_data [0:380];

    initial $readmemh("C:/Users/Nmicps1/Documents/557/interleaver-main/vectors/all_input.txt",in_data);
    initial $readmemh("C:/Users/Nmicps1/Documents/557/interleaver-main/vectors/all_last.txt",in_last);
    initial $readmemh("C:/Users/Nmicps1/Documents/557/interleaver-main/vectors/all_keep.txt",in_keep);
    initial $readmemh("C:/Users/Nmicps1/Documents/557/interleaver-main/vectors/all_output.txt",out_data);
    initial $readmemh("C:/Users/Nmicps1/Documents/557/interleaver-main/vectors/all_config.txt",config_data);
    
/*
 Interleaver_shell Interleaver
    (   .cnData_tdata(tdata_in_config),
        .cnData_tready(tready_in_config),
        .cnData_tvalid(tvalid_in_config),

        .inData_tdata(tdata_in),
        .inData_tkeep(tkeep_in),
        .inData_tvalid(tvalid_in),
        .inData_tready(tready_in),
        .inData_tlast(tlast_in),

        .outData_tdata(tdata_out),
        .outData_tlast(tlast_out),
        .outData_tvalid(tvalid_out),
        .outData_tready(tready_out),

        .ap_rst_n(rst),
        .ap_clk(clk));
*/
interleaver_bd_wrapper INTERLEAVER(
    .cnData_0_tdata(tdata_in_config),
    .cnData_0_tready(tready_in_config),
    .cnData_0_tvalid(tvalid_in_config),
    
    .inData_0_tdata(tdata_in),
    .inData_0_tkeep(tkeep_in),
    .inData_0_tlast(tlast_in),
    .inData_0_tready(tready_in),
    .inData_0_tvalid(tvalid_in),
    
    .outData_0_tdata(tdata_out),
    .outData_0_tlast(tlast_out),
    .outData_0_tready(tready_out),
    .outData_0_tvalid(tvalid_out),
    
    .peripheral_aresetn_0(rst),
    .pl_clk0_0(clk)
);

initial begin


    tdata_in = in_data[0];
    tvalid_in = 1'b1;
    tlast_in = in_last[0];
    tkeep_in = in_keep[0];
    
    
    tdata_in_config = config_data[0];    //Interleaver
    tvalid_in_config = 1'b1;
    
    tready_out = 1'b1;

    i=0; j=0;  k=0;
      
    err_count_tdata_out=0;
    err_tdata_out = 0;
          

end

always@(posedge clk) begin      
    if (tready_in==1'b1 && tvalid_in==1'b1) begin
        #5
        i=(i+1);              
        tdata_in=in_data[i];
        tkeep_in=in_keep[i];
        tlast_in=in_last[i];
    end
end

always@(posedge clk) begin      
    if (tvalid_in_config==1'b1 && tready_in_config==1'b1) begin
        #5
        k=(k+1);              
        tdata_in_config=config_data[k];
    end
end
    

always@(posedge clk) begin  
    if (tvalid_out==1'b1 && tready_out==1'b1) begin                     
        err_tdata_out = out_data[j]^tdata_out;   
        j=j+1;                                                                       
        if (err_tdata_out>0) err_count_tdata_out = err_count_tdata_out+1;
    end
end
endmodule