`timescale 1ns / 1ps





module design_1_wrapper_tb();

reg [127:0]tdata_in;
reg tvalid_in;
wire tready_in;
reg [6:0]tkeep_in;
reg [0:0]tlast_in;


reg [127:0]tdata_in_config;                    //Interleaver
reg tvalid_in_config;
wire tready_in_config;


wire tvalid_out;
reg tready_out;
wire [95:0]tdata_out;
wire [0:0]tlast_out;




reg clk =0;
reg rst =0;

always #5 clk<=~clk;

initial begin
rst =0;
#5000 $finish;
end

integer i,j,k,l;
reg [95:0] err_tdata_out;
integer err_count_tdata_out;





reg [127:0] in_data  [80000:0];
reg [0:0] in_last  [80000:0];
reg [6:0] in_keep  [80000:0];
reg [95:0] out_data [80000:0];
reg [127:0] config_data [0:0];

    initial $readmemh("/home/thrinath/Documents/interleaver/interleaver_concat/vectors_partial/test_case_15_filler_out",in_data);
    initial $readmemh("/home/thrinath/Documents/interleaver/interleaver_concat/vectors_partial/test_case_15_last",in_last);
    initial $readmemh("/home/thrinath/Documents/interleaver/interleaver_concat/vectors_partial/test_case_15_keep",in_keep);
    initial $readmemh("/home/thrinath/Documents/interleaver/interleaver_concat/vectors_partial/test_case_15_concat_out",out_data);
    initial $readmemh("/home/thrinath/Documents/interleaver/interleaver_concat/vectors_partial/test_case_15_config",config_data);
   
    wire  [71:0] KEC_out_tdata;
    wire KEC_out_tready;
    wire KEC_out_tvalid;

    wire [95:0] Concat_out_tdata;
    wire Concat_out_tvalid;
    wire Concat_out_tlast;
    wire Concat_out_tready;
    wire [31:0] fifo_wrc;
   
   
   
   
   
   
   
    KEC_0 KEC (
    .ap_clk(clk),                              // input wire ap_clk
    .ap_rst_n(rst),                          // input wire ap_rst_n
    .config_stream_TDATA(tdata_in_config),    // input wire [127 : 0] config_stream_TDATA
    .config_stream_TREADY(tready_in_config),  // output wire config_stream_TREADY
    .config_stream_TVALID(tvalid_in_config),  // input wire config_stream_TVALID
    .out_stream_TDATA(KEC_out_tdata),          // output wire [71 : 0] out_stream_TDATA
    .out_stream_TREADY(KEC_out_tready),        // input wire out_stream_TREADY
    .out_stream_TVALID(KEC_out_tvalid)        // output wire out_stream_TVALID
);


    Interleaver_shell Interleaver(   
        .KEC_out_tdata(KEC_out_tdata),
        .KEC_out_tready(KEC_out_tready),
        .KEC_out_tvalid(KEC_out_tvalid),

        .inData_tdata(tdata_in),
        .inData_tkeep(tkeep_in),
        .inData_tvalid(tvalid_in),
        .inData_tready(tready_in),
        .inData_tlast(tlast_in),

        .Concat_out_tdata(Concat_out_tdata),
        .Concat_out_tvalid(Concat_out_tvalid),
        .Concat_out_tlast(Concat_out_tlast),
        .Concat_out_tready(Concat_out_tready),
        .fifo_wrc(fifo_wrc),

        .ap_rst_n(rst),
        .ap_clk(clk)
    );


    axis_data_fifo_0 FIFO (
        .s_axis_aresetn(rst),          // input wire s_axis_aresetn
        .s_axis_aclk(clk),                // input wire s_axis_aclk

        .s_axis_tvalid(Concat_out_tvalid),            // input wire s_axis_tvalid
        .s_axis_tready(Concat_out_tready),            // output wire s_axis_tready
        .s_axis_tdata(Concat_out_tdata),              // input wire [95 : 0] s_axis_tdata
        .s_axis_tlast(Concat_out_tlast),              // input wire s_axis_tlast

        .m_axis_tvalid(tvalid_out),            // output wire m_axis_tvalid
        .m_axis_tready(tready_out),            // input wire m_axis_tready
        .m_axis_tdata(tdata_out),              // output wire [95 : 0] m_axis_tdata
        .m_axis_tlast(tlast_out),              // output wire m_axis_tlast

        .axis_wr_data_count(fifo_wrc)  // output wire [31 : 0] axis_wr_data_count
    );
// INST






initial begin


    tdata_in = in_data[1];
    tvalid_in = 1'b1;
    tlast_in = in_last[0];
    tkeep_in = in_keep[0];
    
    
    tdata_in_config = config_data[0];    //Interleaver
    tvalid_in_config = 1'b1;
    
    tready_out = 1'b1;

    i=1; j=0;  k=1;
      
    err_count_tdata_out=0;
    err_tdata_out = 0;
          

end

reg [4:0] reset_counter=0;

always@(posedge clk)begin
    reset_counter <= reset_counter +1;
    if(reset_counter==10) rst <=1;
end

always@(posedge clk) begin      
    if (tready_in==1'b1 && tvalid_in==1'b1) begin
        #5
        i=(i+1);     
        j=j+1; 

        tdata_in=in_data[i];
        tkeep_in=in_keep[j];
        tlast_in=in_last[j];
        end
    end
    

always@(posedge clk) begin  
    if (tvalid_out==1'b1 && tready_out==1'b1) begin                     
        err_tdata_out = out_data[k]^tdata_out;   
        k=k+1;                                                                       
        if (err_tdata_out>0) err_count_tdata_out = err_count_tdata_out+1;
    end
end
endmodule



    /*
    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_filler_out",in_data);
    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_last",in_last);
    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_keep",in_keep);
    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_Interleaver_out",out_data);
    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_config",config_data);
    



    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_filler_out",in_data);
    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_last",in_last);
    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_keep",in_keep);
    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_Interleaver_out",out_data);
    initial $readmemh("/home/thrinath/Documents/Interleaver/Interleaver_test_vectors_IDE/test_case_3_config",config_data);
    

    


    

    */