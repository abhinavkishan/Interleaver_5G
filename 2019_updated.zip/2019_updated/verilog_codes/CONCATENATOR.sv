module CONCATENATOR(
    input logic ap_clk,
    input logic ap_rst_n,

    input logic [95:0] inData_tdata,
    input logic inData_tvalid,
    input logic inData_tlast,
    input logic [5:0] inData_tkeep,

    output logic [95:0] Concat_tdata,
    output logic Concat_tvalid,
    output logic Concat_tlast
);

///////////////////////////////////////// INPUT AXI ////////////////////////////////////////////////
    

//////////////////////////////////////// INPUT AXI END /////////////////////////////////////////////



    logic [5:0] free;
    logic spill;
    logic spill_reg;

    logic buffer_clean;

    always_ff@(posedge ap_clk)begin
        if(!ap_rst_n | inData_tlast) buffer_clean <= 1;
        else buffer_clean <= 0;
    end


    always_comb begin
        spill = 0;
        if(last_reg[0] && free!=48) spill = 1;
        else if(inData_tvalid && (free <= inData_tkeep)) spill = 1;
    end

    always_ff@(posedge ap_clk) begin
        if(!ap_rst_n )spill_reg <=0;
        else spill_reg <= spill;
    end


    always_ff@(posedge ap_clk)begin
        if(buffer_clean) free <= 48;
        else if(inData_tvalid) begin
            if(spill) free <= 48- inData_tkeep + free;
            else free <= free - inData_tkeep;
        end
    end


    wire [5:0] LSC_STAGE1 = buffer_clean?48:free;
    logic [3:0] LSC_STAGE2;



    logic [95:0] LS_OUT_STAGE1;
    logic [95:0] LS_OUT_STAGE2;

    always_ff@(posedge ap_clk)begin
        if(LSC_STAGE1 >=48)LS_OUT_STAGE1 <= 0;
        else if(LSC_STAGE1 >= 32) LS_OUT_STAGE1 <= inData_tdata << 64;
        else if(LSC_STAGE1 >=16)LS_OUT_STAGE1 <= inData_tdata <<32;
        else LS_OUT_STAGE1 <= inData_tdata;

        LSC_STAGE2 <=LSC_STAGE1[3:0];
    end




    wire [5:0] RSC_STAGE1 = buffer_clean?48:(48-free);
    logic [3:0] RSC_STAGE2;

    logic [95:0] RS_OUT_STAGE1;
    logic [95:0] RS_OUT_STAGE2;


    always_ff@(posedge ap_clk)begin
        if(RSC_STAGE1 >= 48) RS_OUT_STAGE1 <= 0;
        else if(RSC_STAGE1 >= 32) RS_OUT_STAGE1 <= inData_tdata >> 64;
        else if(RSC_STAGE1 >=16) RS_OUT_STAGE1 <= inData_tdata >>32;
        else  RS_OUT_STAGE1 <= inData_tdata;

        RSC_STAGE2 <= RSC_STAGE1[3:0];
    end



    always_comb begin
        RS_OUT_STAGE2 = RS_OUT_STAGE1 >> (2*RSC_STAGE2);
        LS_OUT_STAGE2 = LS_OUT_STAGE1 << (2*LSC_STAGE2);
    end


    
    logic [95:0] buffer;
    

    wire [95:0] D1 = LS_OUT_STAGE2;
    wire [95:0] D2 = RS_OUT_STAGE2 | buffer;


    
    logic buffer_write;
    logic buffer_select_line;

    always_ff@(posedge ap_clk) begin
        if(inData_tvalid | buffer_clean)buffer_write <= 1;
        else buffer_write <= 0;

        if(buffer_clean) buffer_select_line <= 1;
        else buffer_select_line <= spill;  
    end

    always_ff@(posedge ap_clk)begin
        if(buffer_write)begin
            if(buffer_select_line)buffer <= D1;
            else buffer <= D2;
        end
    end

    logic last_reg[0:1];

    always_ff@(posedge ap_clk)begin
        if(!ap_rst_n) begin
            last_reg[0] <= 0;
            last_reg[1] <= 0;
        end
        else begin
            last_reg[0] <= inData_tlast;
            last_reg[1] <= last_reg[0];
        end

    end

    always_ff@(posedge ap_clk)begin
        Concat_tdata <= D2;

        if(spill_reg) Concat_tvalid <= 1;
        else Concat_tvalid <= 0;

        if(last_reg[0] && free==48) Concat_tlast <= 1;
        else if(last_reg[1] && spill_reg)Concat_tlast <= 1;
        else Concat_tlast <= 0; 
    end

endmodule
