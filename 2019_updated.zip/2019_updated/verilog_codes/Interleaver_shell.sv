

module Interleaver_shell(
    input logic [71:0] KEC_out_tdata,
    output logic KEC_out_tready,
    input logic KEC_out_tvalid,

    input  logic [127:0] inData_tdata,
    output logic inData_tready,
    input  logic inData_tvalid,
    input  logic inData_tlast,
    input  logic [6:0] inData_tkeep,

    output logic [95:0] Concat_out_tdata,
    output logic Concat_out_tvalid,
    output logic Concat_out_tlast,
    input logic Concat_out_tready,
    input logic [31:0] fifo_wrc,

    input logic ap_clk,
    input logic ap_rst_n
);
    




logic [127:0] pData_tdata;
logic pData_tvalid;
logic pData_tlast;

logic PACKER_trigger;

logic [15:0] N;
logic N_valid;
logic N_ready;

Packer packer(
    .ap_clk(ap_clk),                              // input wire ap_clk
    .ap_rst_n(ap_rst_n),

    .inData_tdata(inData_tdata),
    .inData_tready(inData_tready),
    .inData_tvalid(inData_tvalid),
    .inData_tlast(inData_tlast),
    .inData_tkeep(inData_tkeep),

    .pData_tdata(pData_tdata),
    .pData_tvalid(pData_tvalid),
    .pData_tlast(pData_tlast),
    
    .trigger(PACKER_trigger),

    .N(N),
    .N_valid(N_valid),
    .N_ready(N_ready)
);



wire [14:0] BPR = KEC_out_tdata[66:52];
wire [15:0] E = KEC_out_tdata[51:36];
wire [15:0] Ko = KEC_out_tdata[35:20];
wire [5:0] C= KEC_out_tdata[19:14];
wire [5:0] Cr = KEC_out_tdata[13:8];
wire [3:0] Q = KEC_out_tdata[7:4];
wire [3:0] V = KEC_out_tdata[3:0];




logic [36:0] ImConfig_tdata;
logic ImConfig_tvalid;
logic ImConfig_tready;

logic [15:0] pointer_tdata;
logic pointer_tvalid;

logic [1:0] IM_frame[0:1];
logic [9:0] IM_address[0:1];
logic [47:0] IM_data[0:1];

logic IM_done;


    



control  Control(

    .ap_clk(ap_clk),                              // input wire ap_clk
    .ap_rst_n(ap_rst_n),

    .N_ext(N),
    .N_ext_valid(N_valid),
    .N_ext_ready(N_ready),

    .pData_tdata(pData_tdata),
    .pData_tvalid(pData_tvalid),
    .pData_tlast(pData_tlast),

    .PACKER_trigger(PACKER_trigger),


   //////// CONFIG INFO ///////////////

    .BPR_ext(BPR),
    .E_ext(E),
    .Ko_ext(Ko),
    .Q_ext(Q),
    .V_ext(V),
    .C_ext(C),
    .Cr_ext(Cr),


    .KEC_tvalid(KEC_out_tvalid),
    .KEC_tready(KEC_out_tready),



    .ImConfig_tdata(ImConfig_tdata),
    .ImConfig_tvalid(ImConfig_tvalid),
    .ImConfig_tready(ImConfig_tready),

    .Pointer_tdata(pointer_tdata),
    .Pointer_tvalid(pointer_tvalid),



    .IM_frame(IM_frame),
    .IM_address(IM_address),
    .IM_data(IM_data),
    .IM_done(IM_done)
);


Interleaver_Memory IM(
    .ImConfig_tdata(ImConfig_tdata),
    .ImConfig_tvalid(ImConfig_tvalid),
    .ImConfig_tready(ImConfig_tready),

    .pointer_tdata(pointer_tdata),
    .pointer_tvalid(pointer_tvalid),



    .IM_frame(IM_frame),
    .IM_address(IM_address),
    .IM_data(IM_data),

    


    .Concat_out_tdata(Concat_out_tdata),
    .Concat_out_tlast(Concat_out_tlast),
    .Concat_out_tvalid(Concat_out_tvalid),
    .Concat_out_tready(Concat_out_tready),
    .fifo_wrc(fifo_wrc),

    

    .ap_clk(ap_clk),                              // input wire ap_clk
    .ap_rst_n(ap_rst_n),

    .IM_done(IM_done)
);

endmodule
